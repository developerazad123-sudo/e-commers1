import React, { createContext, useState, useContext, useEffect } from 'react'
import { userAPI } from '../services/api'
import { useAuth } from './AuthContext'
import { useNotification } from './NotificationContext'

const CartContext = createContext()

export const CartProvider = ({ children }) => {
  const { isAuthenticated } = useAuth()
  const { addNotification } = useNotification()
  const [cartItems, setCartItems] = useState([])
  const [loading, setLoading] = useState(false)

  // Load cart from backend on initial load
  useEffect(() => {
    loadCartFromBackend()
  }, [])

  const loadCartFromBackend = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem('token')
      if (token) {
        const response = await userAPI.getCart(token)
        if (response.success) {
          setCartItems(response.data)
        }
      }
    } catch (error) {
      console.error('Failed to load cart from backend:', error)
    } finally {
      setLoading(false)
    }
  }

  const addToCart = async (product) => {
    // Check if user is authenticated
    if (!isAuthenticated) {
      addNotification('Please login to add items to your cart', 'warning')
      setTimeout(() => {
        window.location.href = '/login'
      }, 1500)
      return
    }
    
    try {
      const token = localStorage.getItem('token')
      if (token) {
        // Add to backend cart - send only product ID and quantity
        const productId = product._id || product.id
        const response = await userAPI.addToCart(productId, 1, token)
        if (response.success) {
          setCartItems(response.data)
          addNotification(`${product.name} added to your cart!`, 'success')
        }
      } else {
        // Local storage fallback
        setCartItems(prevItems => {
          // Use _id if available, otherwise use id
          const productId = product._id || product.id
          const existingItem = prevItems.find(item => 
            (item.product ? item.product._id || item.product.id : item._id || item.id) === productId
          )
          if (existingItem) {
            return prevItems.map(item =>
              (item.product ? item.product._id || item.product.id : item._id || item.id) === productId
                ? { ...item, quantity: item.quantity + 1 }
                : item
            )
          } else {
            // Store in the same format as backend (with product nested)
            return [...prevItems, { product: product, quantity: 1 }]
          }
        })
        addNotification(`${product.name} added to your cart!`, 'success')
      }
    } catch (error) {
      console.error('Failed to add to cart:', error)
      // Fallback to local state if backend fails
      setCartItems(prevItems => {
        // Use _id if available, otherwise use id
        const productId = product._id || product.id
        const existingItem = prevItems.find(item => 
          (item.product ? item.product._id || item.product.id : item._id || item.id) === productId
        )
        if (existingItem) {
          return prevItems.map(item =>
            (item.product ? item.product._id || item.product.id : item._id || item.id) === productId
              ? { ...item, quantity: item.quantity + 1 }
              : item
          )
        } else {
          // Store in the same format as backend (with product nested)
          return [...prevItems, { product: product, quantity: 1 }]
        }
      })
      addNotification(`${product.name} added to your cart!`, 'success')
    }
  }

  const removeFromCart = async (productId) => {
    try {
      const token = localStorage.getItem('token')
      if (token) {
        // Remove from backend cart
        const response = await userAPI.removeFromCart(productId, token)
        if (response.success) {
          setCartItems(response.data)
        }
      } else {
        // Local storage fallback
        setCartItems(prevItems => prevItems.filter(item => 
          (item.product ? item.product._id || item.product.id : item._id || item.id) !== productId
        ))
      }
    } catch (error) {
      console.error('Failed to remove from cart:', error)
      // Fallback to local state if backend fails
      setCartItems(prevItems => prevItems.filter(item => 
        (item.product ? item.product._id || item.product.id : item._id || item.id) !== productId
      ))
    }
  }

  const updateQuantity = async (productId, quantity) => {
    if (quantity <= 0) {
      removeFromCart(productId)
      return
    }
    
    try {
      const token = localStorage.getItem('token')
      if (token) {
        // Update in backend cart
        const response = await userAPI.updateCart(productId, quantity, token)
        if (response.success) {
          setCartItems(response.data)
        }
      } else {
        // Local storage fallback
        setCartItems(prevItems =>
          prevItems.map(item =>
            (item.product ? item.product._id || item.product.id : item._id || item.id) === productId 
              ? { ...item, quantity } 
              : item
          )
        )
      }
    } catch (error) {
      console.error('Failed to update quantity:', error)
      // Fallback to local state if backend fails
      setCartItems(prevItems =>
        prevItems.map(item =>
          (item.product ? item.product._id || item.product.id : item._id || item.id) === productId 
            ? { ...item, quantity } 
            : item
        )
      )
    }
  }

  const clearCart = async () => {
    try {
      const token = localStorage.getItem('token')
      if (token) {
        // Clear backend cart
        const response = await userAPI.clearCart(token)
        if (response.success) {
          setCartItems(response.data)
        }
      } else {
        // Local storage fallback
        setCartItems([])
      }
    } catch (error) {
      console.error('Failed to clear cart:', error)
      // Fallback to local state if backend fails
      setCartItems([])
    }
  }

  const getCartTotal = () => {
    return cartItems.reduce((total, item) => {
      // Handle both backend format (item.product) and local format (item directly)
      const product = item.product || item
      const price = product.discount 
        ? product.price * (1 - product.discount / 100)
        : product.price
      return total + (price * (item.quantity || 1))
    }, 0)
  }

  const getCartCount = () => {
    return cartItems.reduce((count, item) => count + (item.quantity || 1), 0)
  }

  const value = {
    cartItems,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    getCartTotal,
    getCartCount,
    loading
  }

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  )
}

export const useCart = () => {
  return useContext(CartContext)
}