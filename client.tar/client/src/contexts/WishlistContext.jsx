import React, { createContext, useState, useContext, useEffect } from 'react'
import { userAPI } from '../services/api'
import { useAuth } from './AuthContext'
import { useNotification } from './NotificationContext'

const WishlistContext = createContext()

export const WishlistProvider = ({ children }) => {
  const { isAuthenticated } = useAuth()
  const { addNotification } = useNotification()
  const [wishlistItems, setWishlistItems] = useState([])
  const [loading, setLoading] = useState(false)

  // Load wishlist from backend on initial load
  useEffect(() => {
    loadWishlistFromBackend()
  }, [])

  const loadWishlistFromBackend = async () => {
    try {
      setLoading(true)
      const token = localStorage.getItem('token')
      if (token) {
        const response = await userAPI.getWishlist(token)
        if (response.success) {
          setWishlistItems(response.data)
        }
      } else {
        // Fallback to local storage
        const savedWishlist = localStorage.getItem('wishlist')
        if (savedWishlist) {
          setWishlistItems(JSON.parse(savedWishlist))
        }
      }
    } catch (error) {
      console.error('Failed to load wishlist from backend:', error)
      // Fallback to local storage
      const savedWishlist = localStorage.getItem('wishlist')
      if (savedWishlist) {
        setWishlistItems(JSON.parse(savedWishlist))
      }
    } finally {
      setLoading(false)
    }
  }

  const addToWishlist = async (product) => {
    // Check if user is authenticated
    if (!isAuthenticated) {
      addNotification('Please login to add items to your wishlist', 'warning')
      setTimeout(() => {
        window.location.href = '/login'
      }, 1500)
      return
    }
    
    try {
      const token = localStorage.getItem('token')
      if (token) {
        // Add to backend wishlist
        const response = await userAPI.addToWishlist(product._id || product.id, token)
        if (response.success) {
          setWishlistItems(response.data)
          addNotification(`${product.name} added to your wishlist!`, 'success')
        }
      } else {
        // Local storage fallback
        setWishlistItems(prevItems => {
          // Use _id if available, otherwise use id
          const productId = product._id || product.id
          const existingItem = prevItems.find(item => (item._id || item.id) === productId)
          if (!existingItem) {
            return [...prevItems, product]
          }
          return prevItems
        })
        addNotification(`${product.name} added to your wishlist!`, 'success')
      }
    } catch (error) {
      console.error('Failed to add to wishlist:', error)
      // Fallback to local state if backend fails
      setWishlistItems(prevItems => {
        // Use _id if available, otherwise use id
        const productId = product._id || product.id
        const existingItem = prevItems.find(item => (item._id || item.id) === productId)
        if (!existingItem) {
          return [...prevItems, product]
        }
        return prevItems
      })
      addNotification(`${product.name} added to your wishlist!`, 'success')
    }
  }

  const removeFromWishlist = async (productId) => {
    try {
      const token = localStorage.getItem('token')
      if (token) {
        // Remove from backend wishlist
        const response = await userAPI.removeFromWishlist(productId, token)
        if (response.success) {
          setWishlistItems(response.data)
        }
      } else {
        // Local storage fallback
        setWishlistItems(prevItems => prevItems.filter(item => (item._id || item.id) !== productId))
      }
    } catch (error) {
      console.error('Failed to remove from wishlist:', error)
      // Fallback to local state if backend fails
      setWishlistItems(prevItems => prevItems.filter(item => (item._id || item.id) !== productId))
    }
  }

  const isInWishlist = (productId) => {
    return wishlistItems.some(item => (item._id || item.id) === productId)
  }

  const clearWishlist = async () => {
    try {
      const token = localStorage.getItem('token')
      if (token) {
        // Clear backend wishlist
        const response = await userAPI.clearWishlist(token)
        if (response.success) {
          setWishlistItems(response.data)
        }
      } else {
        // Local storage fallback
        setWishlistItems([])
      }
    } catch (error) {
      console.error('Failed to clear wishlist:', error)
      // Fallback to local state if backend fails
      setWishlistItems([])
    }
  }

  const value = {
    wishlistItems,
    addToWishlist,
    removeFromWishlist,
    isInWishlist,
    clearWishlist,
    loading
  }

  return (
    <WishlistContext.Provider value={value}>
      {children}
    </WishlistContext.Provider>
  )
}

export const useWishlist = () => {
  return useContext(WishlistContext)
}