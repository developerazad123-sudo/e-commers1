import React from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import CartItem from '../../components/cart/CartItem'
import { useCart } from '../../contexts/CartContext'
import { formatCurrency } from '../../utils/format'
import { useNotification } from '../../contexts/NotificationContext'

const Cart = () => {
  const navigate = useNavigate()
  const { cartItems, updateQuantity, removeFromCart, getCartTotal, clearCart } = useCart()
  const { addNotification } = useNotification()

  const handleCheckout = () => {
    // Redirect to checkout page
    navigate('/checkout')
  }

  const handleBuyNow = () => {
    // Redirect to checkout page for immediate purchase
    navigate('/checkout')
  }

  const subtotal = getCartTotal()
  const tax = subtotal * 0.08
  const total = subtotal + tax

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  }

  return (
    <div className="min-h-screen bg-light-grey">
      <motion.div 
        className="max-w-7xl mx-auto px-4 py-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <motion.h1 
          className="text-4xl font-bold text-dark-grey mb-8"
          initial={{ y: -20 }}
          animate={{ y: 0 }}
          transition={{ delay: 0.2 }}
        >
          Shopping Cart
        </motion.h1>
        
        {cartItems.length === 0 ? (
          <motion.div 
            className="bg-white rounded-xl shadow-lg p-8 text-center"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <div className="bg-gray-200 border-2 border-dashed rounded-xl w-24 h-24 mx-auto mb-6" />
            <h2 className="text-2xl font-semibold mb-4 text-dark-grey">Your cart is empty</h2>
            <p className="text-gray-600 mb-6">Add some products to your cart</p>
            <motion.a 
              href="/products" 
              className="btn-primary inline-block"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Continue Shopping
            </motion.a>
          </motion.div>
        ) : (
          <motion.div 
            className="grid grid-cols-1 lg:grid-cols-3 gap-8"
            variants={container}
            initial="hidden"
            animate="show"
          >
            {/* Cart Items */}
            <motion.div 
              className="lg:col-span-2"
              variants={item}
            >
              <div className="bg-white rounded-xl shadow-lg">
                <div className="p-6">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-semibold text-dark-grey">Cart ({cartItems.reduce((count, item) => count + (item.quantity || 0), 0)} items)</h2>
                    <motion.button 
                      onClick={clearCart}
                      className="text-red-600 hover:text-red-800"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      Clear Cart
                    </motion.button>
                  </div>
                  
                  <div className="divide-y">
                    {cartItems.map((item) => (
                      <motion.div
                        key={item._id || item.id || item.product?._id || item.product?.id}
                        variants={item}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                      >
                        <CartItem
                          item={item}
                          onUpdateQuantity={updateQuantity}
                          onRemove={removeFromCart}
                        />
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Order Summary - Always show even when cart is empty */}
            <motion.div
              variants={item}
            >
              <div className="bg-white rounded-xl shadow-lg p-6 sticky top-8">
                <h2 className="text-2xl font-semibold mb-6 text-dark-grey">Order Summary</h2>
                
                <div className="space-y-4 mb-6">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>{formatCurrency(subtotal)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>Free</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax</span>
                    <span>{formatCurrency(tax)}</span>
                  </div>
                  <div className="border-t pt-4 flex justify-between font-semibold text-lg">
                    <span>Total</span>
                    <span>{formatCurrency(total)}</span>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <motion.button
                    onClick={handleBuyNow}
                    className="w-full btn-success"
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.98 }}
                    disabled={cartItems.length === 0}
                  >
                    Buy Now
                  </motion.button>
                  
                  <motion.button
                    onClick={handleCheckout}
                    className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-4 rounded-lg transition duration-300"
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.98 }}
                    disabled={cartItems.length === 0}
                  >
                    Proceed to Checkout
                  </motion.button>
                </div>
                
                <motion.a 
                  href="/products" 
                  className="block text-center mt-4 text-blue-600 hover:text-blue-800"
                  whileHover={{ x: 5 }}
                >
                  Continue Shopping
                </motion.a>
              </div>
            </motion.div>
          </motion.div>
        )}
      </motion.div>
    </div>
  )
}

export default Cart