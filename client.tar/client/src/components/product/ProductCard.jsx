import React from 'react'
import { useCart } from '../../contexts/CartContext'
import { useWishlist } from '../../contexts/WishlistContext'
import { useNotification } from '../../contexts/NotificationContext'
import { formatCurrency } from '../../utils/format'
import { motion } from 'framer-motion'

const ProductCard = ({ product }) => {
  const { addToCart } = useCart()
  const { addToWishlist, isInWishlist } = useWishlist()
  const { addNotification } = useNotification()

  const handleAddToCart = (e) => {
    e.preventDefault()
    e.stopPropagation()
    // Ensure we're passing the correct product object with _id
    addToCart(product)
    addNotification(`${product.name} added to your cart!`, 'success')
  }

  const handleAddToWishlist = (e) => {
    e.preventDefault()
    e.stopPropagation()
    // Ensure we're passing the correct product object with _id
    addToWishlist(product)
    addNotification(`${product.name} added to your wishlist!`, 'success')
  }

  const handleImageClick = (e) => {
    e.preventDefault()
    // Get the product ID (use _id if available, otherwise id)
    const productId = product?._id || product?.id
    // Redirect to product detail page
    window.location.href = `/product/${productId}`
  }

  const discountedPrice = product?.discount 
    ? product.price * (1 - product.discount / 100)
    : product?.price

  // Function to get product image URL based on product name and category
  const getImageUrl = (product) => {
    if (!product) return 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&h=300';
    
    // Check if image is an external URL (Unsplash, etc.)
    const isExternalUrl = product.image && (
      product.image.startsWith('http://') || 
      product.image.startsWith('https://')
    );
    
    // For local images, use the correct path
    // For external images, use as is
    if (isExternalUrl) {
      return product.image;
    }
    
    // If product has a specific local image, use it with the correct path
    if (product.image && product.image !== 'no-photo.jpg' && product.image !== '/uploads/no-photo.jpg') {
      // Check if the image path already starts with /uploads/
      if (product.image.startsWith('/uploads/')) {
        return `http://localhost:5000${product.image}`;
      } else {
        // Add /uploads/ prefix
        return `http://localhost:5000/uploads/${product.image}`;
      }
    }
    
    // For default no-photo image, use the correct path
    if (product.image === '/uploads/no-photo.jpg' || product.image === 'no-photo.jpg') {
      return 'http://localhost:5000/uploads/no-photo.jpg';
    }
    
    // Generate image based on product name and category
    const name = product.name?.toLowerCase() || '';
    const category = product.category?.toLowerCase() || '';
    
    // Technology products
    if (category.includes('technology') || category.includes('tech')) {
      if (name.includes('iphone') || name.includes('phone') || name.includes('mobile')) {
        return 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('macbook') || name.includes('laptop') || name.includes('computer')) {
        return 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('headphone') || name.includes('earbud')) {
        return 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('tv') || name.includes('television')) {
        return 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('tablet')) {
        return 'https://images.unsplash.com/photo-1542751110-97427bbecf20?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('watch')) {
        return 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('camera')) {
        return 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=400&h=300';
      } else {
        return 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=400&h=300';
      }
    }
    
    // Clothing products
    if (category.includes('clothing') || category.includes('fashion')) {
      if (name.includes('shirt') || name.includes('t-shirt')) {
        return 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('shoe') || name.includes('sneaker')) {
        return 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('dress')) {
        return 'https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('jeans') || name.includes('pants')) {
        return 'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('jacket') || name.includes('coat')) {
        return 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=400&h=300';
      } else {
        return 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=400&h=300';
      }
    }
    
    // Home appliances
    if (category.includes('home') || category.includes('appliance')) {
      if (name.includes('washing') || name.includes('washer')) {
        return 'https://images.unsplash.com/photo-1574672546621-6904455c6c4c?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('refrigerator') || name.includes('fridge')) {
        return 'https://images.unsplash.com/photo-1542751110-97427bbecf20?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('microwave')) {
        return 'https://images.unsplash.com/photo-1542751110-97427bbecf20?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('ac') || name.includes('air conditioner')) {
        return 'https://images.unsplash.com/photo-1542751110-97427bbecf20?auto=format&fit=crop&w=400&h=300';
      } else if (name.includes('tv') || name.includes('television')) {
        return 'https://images.unsplash.com/photo-1542751110-97427bbecf20?auto=format&fit=crop&w=400&h=300';
      } else {
        return 'https://images.unsplash.com/photo-1542751110-97427bbecf20?auto=format&fit=crop&w=400&h=300';
      }
    }
    
    // Default image
    return 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&h=300';
  }

  // Get the product ID (use _id if available, otherwise id)
  const productId = product?._id || product?.id

  // Handle image loading errors
  const handleImageError = (e) => {
    e.target.src = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=400&h=300';
  };

  return (
    <motion.div 
      className="bg-white rounded-xl shadow-lg overflow-hidden h-full flex flex-col"
      whileHover={{ y: -10 }}
      transition={{ type: "spring", stiffness: 300 }}
    >
      <motion.div 
        onClick={handleImageClick}
        className="cursor-pointer"
        whileHover={{ scale: 1.02 }}
        transition={{ duration: 0.3 }}
      >
        <img 
          src={getImageUrl(product)} 
          alt={product?.name || 'Product'} 
          className="w-full h-48 object-cover"
          onError={handleImageError}
        />
      </motion.div>
      <div className="p-6 flex-grow flex flex-col">
        <div className="flex justify-between items-start mb-2">
          <motion.div 
            onClick={handleImageClick}
            className="cursor-pointer block"
            whileHover={{ x: 5 }}
          >
            <h3 className="font-semibold text-lg text-dark">
              {product?.name || 'Product Title'}
            </h3>
          </motion.div>
          {product?.discount && product.discount > 0 && (
            <span className="bg-red-100 text-red-800 text-xs font-semibold px-2.5 py-0.5 rounded">
              {product.discount}% OFF
            </span>
          )}
        </div>
        <p className="text-neutral text-sm mb-4">{product?.category || 'Category'}</p>
        <div className="mt-auto">
          <div className="flex justify-between items-center mb-4">
            <div>
              {product?.discount && product.discount > 0 ? (
                <>
                  <span className="font-bold text-xl text-dark">{formatCurrency(discountedPrice)}</span>
                  <span className="ml-2 text-sm text-neutral line-through">{formatCurrency(product?.price)}</span>
                </>
              ) : (
                <span className="font-bold text-xl text-dark">{formatCurrency(product?.price)}</span>
              )}
            </div>
          </div>
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
            <motion.button 
              onClick={handleAddToCart}
              className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition duration-300 ease-in-out flex-grow"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.9 }}
            >
              Add to Cart
            </motion.button>
            <motion.button 
              onClick={handleAddToWishlist}
              className={`p-2 rounded-full ${
                isInWishlist(productId)
                  ? 'text-red-500 hover:text-red-700 bg-red-50'
                  : 'text-gray-400 hover:text-red-500 bg-gray-100'
              }`}
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
            >
              <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
            </motion.button>
          </div>
        </div>
      </div>
    </motion.div>
  )
}

export default ProductCard