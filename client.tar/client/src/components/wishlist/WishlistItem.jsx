import React from 'react'
import { useNotification } from '../../contexts/NotificationContext'
import { formatCurrency } from '../../utils/format'
import { motion } from 'framer-motion'

const WishlistItem = ({ item, onAddToCart, onRemove }) => {
  const { addNotification } = useNotification()
  // Get the product ID (use _id if available, otherwise id)
  const productId = item?.product?._id || item?.product?.id || item?._id || item?.id

  // Access product details from the nested product object
  const product = item?.product || item

  const discountedPrice = product?.discount 
    ? product.price * (1 - product.discount / 100)
    : product?.price

  return (
    <motion.div 
      className="flex flex-col sm:flex-row sm:items-center border-b py-4 gap-4"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {/* Display product image */}
      {product?.image ? (
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-24 h-24 object-contain rounded-xl"
        />
      ) : (
        <div className="w-24 h-24 bg-gray-200 border-2 border-dashed rounded-xl" />
      )}
      
      <div className="flex-1">
        <h3 className="font-semibold text-dark-grey">{product?.name || 'Product Name'}</h3>
        <p className="text-gray-600 text-sm">{product?.category || 'Category'}</p>
        <div className="flex items-center mt-2">
          <span className="font-bold text-dark-grey">{formatCurrency(discountedPrice)}</span>
          {product?.discount && (
            <span className="ml-2 bg-red-100 text-red-800 text-xs font-semibold px-2 py-0.5 rounded">
              {product.discount}% OFF
            </span>
          )}
        </div>
      </div>
      <div className="flex flex-wrap items-center space-x-4 gap-y-2">
        <motion.button 
          onClick={() => {
            onAddToCart(product)
            addNotification(`${product.name} added to your cart!`, 'success')
          }}
          className="btn-primary px-4 py-2 text-sm"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Add to Cart
        </motion.button>
        <motion.button 
          onClick={() => onRemove(productId)}
          className="text-red-500 hover:text-red-700"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
          </svg>
        </motion.button>
      </div>
    </motion.div>
  )
}

export default WishlistItem